package StockPortfolioManagement;

public interface StockPortfolioInterface {
    void PopulateTable();
}
